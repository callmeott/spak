The objective of UNIT4 is for testing
newly added feature of "UNIQUE" flag for
slots of type INSTANCE.

- Load unit4.xml and start unit4_client.jar
- Make connection from client.
- Draw a line
- Draw a circle. At this stage, a Pole should appear.
- Draw another circle. We have 2 circle instances now
  but no new pole should appear. The content of prev
  pole should be updated with new Circle and corresponding
  message is printed.
  
  