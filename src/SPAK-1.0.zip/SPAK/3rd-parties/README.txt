Third-parties software used by SPAK

-Rhino Javascript for JAVA
http://www.mozilla.org/rhino/
License: NPL, GPL

-Apache XML-RPC
http://ws.apache.org/xmlrpc/
License: The Apache License

-Kunststoff look'n feel
http://www.incors.org/
