This is SPAK: Software Platform for Agents and Knowledge

SPAK 1.0: Copyright (c) 2002-2008 National Institute of Informatics
(NII), Tokyo, Japan, under the GNU General Public License (GPL) Version
2.0 or later.

SPAK was developed by and used in several research projects at the
laboratory of Prof. Dr. Haruki Ueno at the National Institute of
Informatics during 2002 - 2008 and later released as Open Source software
in July 2008.

SPAK contributors:
-Dr.Vuthichai Ampornaramveth (principal developer)
-Dr.Pattara Kiatisevi (developer)
-Dr.Zhang Tao (user)
-Dr.Hasan Hasanuzzaman (user)
-Prof. Dr. Haruki Ueno (advisor, laboratory director)
(http://research.nii.ac.jp/~ueno)
